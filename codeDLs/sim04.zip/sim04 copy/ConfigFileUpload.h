/**
*  @file ConfigFileUpload.h
*
*  @details : Typedefs data structure for config data and function declarations.
*
*  @version 1.2
*
*  @note : requires Utility.h
*/
#ifndef CONFIG_UPLOAD_H
#define CONFIG_UPLOAD_H

#include <stdio.h>
#include <stdlib.h>
#include "Utility.h"

//Data structure to hold configuration file data
typedef struct ConfigData
{
   int version;
   char filePath[255];
   char scheduleCode[255];
   int quantumTime;
   int memoryAvailable;
   int processerCycleTime;
   int ioCycleTime;
   char logTo[255];
   char logFilePath[255];

} ConfigData;


//function declarations
ERROR_CODE ReadConfigFile(char *, ConfigData *);
int checkVersion(int);
int checkCPUScheduleCode(char *);
int checkQuantumTime(int);
int checkMemoryAvailable(int);
int checkProcessorCycleTime(int);
int checkIOCycleTime(int);
int checkLogTo(char *);
int checkLogFilePath(char *);
int checkConfigData(ConfigData *);


#endif
