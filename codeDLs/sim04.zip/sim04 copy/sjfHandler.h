/**
*  @file sjfHandler.h
*
*  @details: Contains function delcarations for sjfHandler.c
*              as well as all include statements sjfHandler.c needs
*
*/
#ifndef SJF_HANDLER_H
#define SJF_HANDLER_H

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#include "Utility.h"
#include "MetadataFileUpload.h"
#include "ConfigFileUpload.h"
#include "processHandler.h"

//Attempt at making a ProcTimesNode LinkedList
typedef struct ProcTimesNode
{
  int procNum;
  unsigned long totalProcTime;

  struct ProcTimesNode *nextNode; //defaults to null

} ProcTimesNode;

//Struct to hold allocated memory, MMU
typedef struct MMU
{
  int segment;
  int memBase;
  int memAlloc;

} MMU;


//Function Declarations:
int checkForSJF(char *scheduleCode);
int memoryChecker(MetadataNode **currentNode, ConfigData *configStruct,
                                                            MMU *memAllocated);
int memoryAccess(MetadataNode **currentNode, ConfigData *configStruct,
                                                            MMU *memAllocated);
void calcProcessTimes(MetadataNode **currentNode , ConfigData *configStruct,
                                                          ProcTimesNode *lCur);

#endif //SJF_HANDLER_H
