/**
*  @file Utility.h
*
*  @details : Defines constants and error codes and declares utility functions.
*
*  @version 1.2
*
*/
#ifndef UTILITY_H
#define UTILITY_H

#include <stdio.h>
#include <stdlib.h>

static const char READ_ONLY_FLAG[] = "r";

typedef enum ERROR_CODE
{FILE_READ_ERROR, FILE_OPEN_ERROR, SUCCESS} ERROR_CODE;


int charInString(char, char*);
int charToInt(char);
int isDigit(char *);
int stringToInt(char *);
void Strip(char *);
int StringLength(char *);
int StringCompare(char *, char *);
void StringCopy(char *, char *);

#endif
