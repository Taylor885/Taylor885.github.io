/**
*  @file processHandler.h
*
*  @details: Contains function delcarations for processHandler.c
*              as well as all include statements processHandler.c needs
*
*/
#ifndef PROCESS_HANDLER_H
#define PROCESS_HANDLER_H

#include <stdio.h>
#include <stdlib.h>
#include <string.h>
#include <pthread.h>

#include "Utility.h"
#include "MetadataFileUpload.h"
#include "ConfigFileUpload.h"
#include <sys/time.h>
#include "sjfHandler.h"


//Function Declarations:
void whereLogTo (ConfigData *configStruct, char *homie, FILE **fPtr);
void *makeWait(void *wTime);
void processMetadata ( MetadataNode **headNode, ConfigData *configData, int sjfFlag, MMU *memAllocated);
unsigned long calcTime(struct timeval startTime);

#endif //PROCESS_HANDLER_H
