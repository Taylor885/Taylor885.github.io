/**
*  @file cpuHandler.h
*
*  @details: Contains function delcarations for cpuHandler.c
*              as well as all include statements cpuHandler.c needs
*
*/
#ifndef CPU_HANDLER_H
#define CPU_HANDLER_H

#include <stdio.h>
#include <stdlib.h>
#include <pthread.h>

#include "Utility.h"
#include "MetadataFileUpload.h"
#include "ConfigFileUpload.h"
#include "processHandler.h"
#include "sjfHandler.h"

//Function Declarations:
int checkCPUCode(char *scheduleCode);


#endif //CPU_HANDLER_H
