/**
*  @file ConfigFileUpload.c
*
*  @details : Contains functions which read and check the config file.
*
*  @version 1.2
*
*  @note : requires ConfigFileUpload.h and Utility.h
*/
#ifndef CONFIG_UPLOAD_C
#define CONFIG_UPLOAD_C

#include "ConfigFileUpload.h"
#include "Utility.h"


ERROR_CODE ReadConfigFile(char *fileName, ConfigData *configData)
{
   FILE *filePtr;
   int lineNumber = 1;
   int lineBufferIndex;
   int tempBufferIndex;
   char *lineBuffer = malloc(sizeof(char) * 255);
   char *tempBuffer = malloc(sizeof(char) * 255);
   char *tempBuffer2 = malloc(sizeof(char) * 255);
   int running = 1;

   filePtr = fopen(fileName, READ_ONLY_FLAG);
   if(filePtr == NULL)
   {
     free(tempBuffer);
     free(tempBuffer2);
     free(lineBuffer);
     return FILE_OPEN_ERROR;
   }

   configData->filePath[0] = '\0';
   configData->logFilePath[0] = '\0';

   while(!feof(filePtr) && running == 1)
   {
     fgets(lineBuffer, 255, filePtr);
     //Skips first line of config file
     if(lineNumber != 1)
     {
        //deal with current line
        lineBufferIndex = 0;
        Strip(lineBuffer);

        while(lineBuffer[lineBufferIndex] != ':' &&
                                            lineBuffer[lineBufferIndex] != 0)
        {
           tempBuffer[lineBufferIndex] = lineBuffer[lineBufferIndex];
           lineBufferIndex++;
        }
        tempBuffer[lineBufferIndex] = 0;
        lineBufferIndex++;

        tempBufferIndex = 0;

        while(lineBuffer[lineBufferIndex] != '\n' &&
                                              lineBuffer[lineBufferIndex] !=0)
        {
          tempBuffer2[tempBufferIndex] = lineBuffer[lineBufferIndex];
          tempBufferIndex++;
          lineBufferIndex++;
        }

        tempBuffer2[tempBufferIndex] = 0;

        if(StringCompare(tempBuffer, "Version/Phase") == 0)
        {
           int version = tempBuffer2[0] - '0';
           if(checkVersion(version) != 0)
           {
             fclose(filePtr);
             free(tempBuffer);
             free(tempBuffer2);
             free(lineBuffer);
             return FILE_READ_ERROR;
           }
           configData->version = version;
        }
        else if(StringCompare(tempBuffer, "FilePath") == 0)
        {
           StringCopy(configData->filePath, tempBuffer2);
        }
        else if(StringCompare(tempBuffer, "CPUSchedulingCode") == 0)
        {
           if(checkCPUScheduleCode(tempBuffer2) != 0)
           {
             fclose(filePtr);
             free(tempBuffer);
             free(tempBuffer2);
             free(lineBuffer);
             return FILE_READ_ERROR;
           }
           StringCopy(configData->scheduleCode, tempBuffer2);
        }
        else if(StringCompare(tempBuffer, "QuantumTime(cycles)") == 0)
        {
           int tempTime = stringToInt(tempBuffer2);
           if(checkQuantumTime(tempTime) != 0)
           {
             fclose(filePtr);
             free(tempBuffer);
             free(tempBuffer2);
             free(lineBuffer);
             return FILE_READ_ERROR;
           }
           configData->quantumTime = tempTime;
        }
        else if(StringCompare(tempBuffer, "MemoryAvailable(KB)") == 0)
        {
           int tempMemory = stringToInt(tempBuffer2);
           if(checkMemoryAvailable(tempMemory) != 0)
           {
             fclose(filePtr);
             free(tempBuffer);
             free(tempBuffer2);
             free(lineBuffer);
             return FILE_READ_ERROR;
           }
           configData->memoryAvailable = tempMemory;
        }
        else if(StringCompare(tempBuffer, "ProcessorCycleTime(msec)") == 0)
        {
           int tempCycleTime = stringToInt(tempBuffer2);
           if(checkProcessorCycleTime(tempCycleTime) != 0)
           {
             fclose(filePtr);
             free(tempBuffer);
             free(tempBuffer2);
             free(lineBuffer);
             return FILE_READ_ERROR;
           }
           configData->processerCycleTime = tempCycleTime;
        }
        else if(StringCompare(tempBuffer, "I/OCycleTime(msec)") == 0)
        {
           configData->ioCycleTime = stringToInt(tempBuffer2);
        }
        else if(StringCompare(tempBuffer, "LogTo") == 0)
        {
           if(checkLogTo(tempBuffer2) != 0)
           {
             fclose(filePtr);
             free(tempBuffer);
             free(tempBuffer2);
             free(lineBuffer);
             return FILE_READ_ERROR;
           }
           StringCopy(configData->logTo, tempBuffer2);
        }
        else if(StringCompare(tempBuffer, "LogFilePath") == 0)
        {
           if(checkLogFilePath(tempBuffer) != 0)
           {
             fclose(filePtr);
             free(tempBuffer);
             free(tempBuffer2);
             free(lineBuffer);
             return FILE_READ_ERROR;
           }
           StringCopy(configData->logFilePath, tempBuffer2);
        }
        else if(StringCompare(tempBuffer, "EndSimulatorConfigurationFile.") == 0)
        {
          fclose(filePtr);
          free(tempBuffer);
          free(tempBuffer2);
          free(lineBuffer);
           if(checkConfigData(configData) != 0)
           {

             return FILE_READ_ERROR;
           }
           return SUCCESS;
        }
        else
        {
           fclose(filePtr);
           free(tempBuffer);
           free(tempBuffer2);
           free(lineBuffer);
           return FILE_READ_ERROR;
        }
     }
    lineNumber++;
   }
   fclose(filePtr);
   free(tempBuffer);
   free(tempBuffer2);
   free(lineBuffer);
   if(checkConfigData(configData) != 0)
   {
     printf("Checked config data...\n");
     return FILE_READ_ERROR;
   }
   return SUCCESS;
}


int checkVersion(int inVersion)
{
  if(inVersion < 1 || inVersion > 10)
  {
    return -1;
  }
  return 0;
}

int checkCPUScheduleCode(char * inCode)
{
  if(StringCompare(inCode, "NONE") == 0 ||
     StringCompare(inCode, "FCFS-N") == 0 ||
     StringCompare(inCode, "SJF-N") == 0 ||
     StringCompare(inCode, "FCFS-P") == 0 ||
     StringCompare(inCode, "SRTF-P") == 0 ||
     StringCompare(inCode, "RR-P") == 0)
     {
       return 0;
     }

     return -1;
}

int checkQuantumTime(int inTime)
{
  if(inTime < 0 || inTime > 100)
  {
    return -1;
  }

  return 0;
}

int checkMemoryAvailable(int inMemory)
{
  if(inMemory < 0 || inMemory > 1048576)
  {
    return -1;
  }
  return 0;
}

int checkProcessorCycleTime(int inTime)
{
  if(inTime < 0 || inTime > 1000)
  {
    return -1;
  }

  return 0;
}

int checkIOCycleTime(int inTime)
{
  if(inTime < 0 || inTime > 10000)
  {
    return -1;
  }
  return 0;
}

int checkLogTo(char * inString)
{
  if(StringCompare(inString, "Monitor") == 0 ||
     StringCompare(inString, "File") == 0 ||
     StringCompare(inString, "Both") == 0)
     {
       return 0;
     }

     return -1;
}

int checkLogFilePath(char *inString)
{
  if(StringLength(inString) > 0)
  {
    return 0;
  }
  return -1;
}

int checkConfigData(ConfigData *inStruct)
{
  if(checkVersion(inStruct->version) != 0 ||
     checkLogFilePath(inStruct->filePath) != 0 ||
     checkCPUScheduleCode(inStruct->scheduleCode) != 0 ||
     checkQuantumTime(inStruct->quantumTime) != 0 ||
     checkMemoryAvailable(inStruct->memoryAvailable) != 0 ||
     checkProcessorCycleTime(inStruct->processerCycleTime) != 0 ||
     checkIOCycleTime(inStruct->ioCycleTime) != 0 ||
     checkLogTo(inStruct->logTo) != 0 ||
     checkLogFilePath(inStruct->logFilePath) != 0)
     {
       return -1;
     }
   return 0;
}


#endif
