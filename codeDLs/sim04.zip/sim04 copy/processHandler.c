/**
*  @file processHandler.c
*
*  @details : Contains functions that read MetaDataNoes, outputs to
*              Monitor, file, or both.  Creates threads, and a time
                to make threads wait.
*
*  @version 1.2
*
*  @note : makeWait function inspired by Prof. Levrington's
*            runTimer() code.
**/

#ifndef PROCESS_HANDLER_C
#define PROCESS_HANDLER_C


#include "processHandler.h"
#include "MetadataFileUpload.h"
#include "Utility.h"
#include "ConfigFileUpload.h"


/* Function Checks if Log To is Montior, File, or both.
                              Then calls appropriate actions */
void whereLogTo(ConfigData *configStruct, char *line, FILE **fPtr)
{
  if(StringCompare(configStruct->logTo, "Monitor") == 0)
  {
    printf("%s", line);
  }
  else if(StringCompare(configStruct->logTo, "File") == 0)
  {
    fprintf(*fPtr, "%s", line);
  }
  else if(StringCompare(configStruct->logTo, "Both") == 0)
  {
    printf("%s", line);
    fprintf(*fPtr, "%s", line);
  }
}


/* Thread functions always need to be void *,
   Takes in a milliSeconds and waits that length,
 */
void *makeWait(void *wTime)
{
  //recast paramter to an int
  int waitTime = *(int *)wTime;

  int startSec, startUSec, stopSec, stopUSec;
  int uSecDiff, secDiff, mSecDiff;
  int timeDiff = 0;

  struct timeval currentTime, stopTime;
  gettimeofday(&currentTime, NULL);

  startSec = currentTime.tv_sec;
  startUSec = currentTime.tv_usec;

  //while 0 < 5 (ex: placeHolderTime)
  while (timeDiff < waitTime)
  {
    gettimeofday(&stopTime, NULL);
    stopSec = stopTime.tv_sec;
    stopUSec = stopTime.tv_usec;
    uSecDiff = stopUSec - startUSec;

    //if stopSec less then startUsec
    if(uSecDiff < 0)
    {
      //Then: no diff in uSecs, and add a 1000000
      uSecDiff = uSecDiff + 1000000;
      stopSec = stopSec -1;
    }

    mSecDiff = uSecDiff/1000;
    secDiff = (stopSec - startSec) * 1000;
    timeDiff = secDiff + mSecDiff;
  }
  return NULL;
}


void processMetadata(MetadataNode **headNode, ConfigData *configStruct,
                                        int cpuCheck, MMU *memAllocated)
{
  //Store ioCycleTime and processerCycleTime
  int ioTime = configStruct->ioCycleTime;
  int processTime = configStruct->processerCycleTime;

  ProcTimesNode *leadNode =(MMU *)malloc(sizeof(MMU));

  int passTime;
  char lineHolder[80];
  pthread_t workerThread;

  MetadataNode *temp = *headNode;
  int processNum = -1;
  FILE *fp = fopen(configStruct->logFilePath, "ab+");

  //Stucts to hold "Starting Time", and time elapsed/current
  struct timeval startTime;
  gettimeofday(&startTime, NULL);

  int endProcessFlag = 0;

  //While not at end of LinkedList, aka still in Metadata Nodes
  while(temp != NULL)
  {
    //last node:
    if(charInString(temp->component, "S") == 0  &&
                                    StringCompare(temp->operation, "end") == 0)
    {
      break; //breaks out of/exits loop
    }
    //first start node (not necessarily needed, but wanted to check):
    else if(charInString(temp->component, "S") == 0  &&
                                  StringCompare(temp->operation, "start") == 0)
    {
      //Start: calculating a process time as Example:
      calcProcessTimes(&temp, configStruct, leadNode);
      printf("Example of Calculated Process Time: %ld \n",
                                                      leadNode->totalProcTime);
      //Point node to next and skip to top of Loop
      temp = temp->nextNode;
      continue; //skips to top of loop
    }
    //new process start Node:
    else if(charInString(temp->component, "A") == 0  &&
                                  StringCompare(temp->operation, "start") == 0)
    {
      //Turn of end Process, in case it is on
      endProcessFlag = 0;
      processNum++;

      /* Switch Statement to Check CPU code.  Specific sorting algorithm would
      be implemented here */
      switch(cpuCheck)
      {
        case 1:
          sprintf(lineHolder,
            "Time: %ld, FCFS-N Strategy selects Process %d with time: * \n",
                                              calcTime(startTime), processNum);
          break;
        case 2:
          sprintf(lineHolder,
            "Time: %ld, SJF-N Strategy selects Process %d with time: * \n",
                                              calcTime(startTime), processNum);
          break;
        case 3:
        sprintf(lineHolder,
          "Time: %ld, FCFS-P Strategy selects Process %d with time: * \n",
                                            calcTime(startTime), processNum);
          break;
        case 4:
        sprintf(lineHolder,
          "Time: %ld, SRTF-P Strategy selects Process %d with time: * \n",
                                            calcTime(startTime), processNum);
          break;
        case 5:
        sprintf(lineHolder,
          "Time: %ld, RR-P Strategy selects Process %d with time: * \n",
                                            calcTime(startTime), processNum);
          break;
      }


      whereLogTo(configStruct, lineHolder , &fp);

      sprintf(lineHolder, "Time: %ld, Process %d set in Running state \n",
                                            calcTime(startTime), processNum);
      whereLogTo(configStruct, lineHolder , &fp);
    }
    //end process Node:
    else if(charInString(temp->component, "A") == 0  &&
                                    StringCompare(temp->operation, "end") == 0)
    {
      sprintf(lineHolder, "Time: %ld, Process %d set in Exit state \n",
                                              calcTime(startTime), processNum);
      whereLogTo(configStruct, lineHolder, &fp);
    }
    //else a "Normal" node - call waitTime()s:
    else
    {
      if (endProcessFlag)
      {
        temp = temp->nextNode;
        continue;
      }
      else
      {
        //handle Memory:   ------Sim03 HERE:-------
        if(charInString(temp->component, "M") == 0)
        {
          //Allocate
          if(StringCompare(temp->operation, "allocate") == 0)
          {
            sprintf(lineHolder,
                  "Time: %ld, Process %d, MMU allocation: %d \n",
                                  calcTime(startTime), processNum, temp->value);
            whereLogTo(configStruct, lineHolder, &fp);

            int memReturn = memoryChecker(&temp, configStruct, memAllocated);
            if(memReturn)
            {
              sprintf(lineHolder,
                    "Time: %ld, Process %d, MMU allocation: Successful \n",
                                              calcTime(startTime), processNum);
              whereLogTo(configStruct, lineHolder, &fp);
            }
            else
            {
              sprintf(lineHolder,
                    "Time: %ld, Process %d, MMU allocation: Failed \n",
                                              calcTime(startTime), processNum);
              whereLogTo(configStruct, lineHolder, &fp);
              sprintf(lineHolder,
                    "Time: %ld, Process %d, Seg Fault - Process Ended \n",
                                              calcTime(startTime), processNum);
              whereLogTo(configStruct, lineHolder, &fp);
              sprintf(lineHolder,
                    "Time: %ld, Process %d, set in Exit State \n",
                                              calcTime(startTime), processNum);
              whereLogTo(configStruct, lineHolder, &fp);
              endProcessFlag = 1;
            }
          }
          //Access
          else if(StringCompare(temp->operation, "access") == 0)
          {
            sprintf(lineHolder,
                  "Time: %ld, Process %d, MMU access: %d \n",
                                  calcTime(startTime), processNum, temp->value);
            whereLogTo(configStruct, lineHolder, &fp);

            int memReturn = memoryAccess(&temp, configStruct, memAllocated);
            if(memReturn)
            {
              sprintf(lineHolder,
                    "Time: %ld, Process %d, MMU access: Successful \n",
                                              calcTime(startTime), processNum);
              whereLogTo(configStruct, lineHolder, &fp);
            }
            else
            {
              sprintf(lineHolder,
                    "Time: %ld, Process %d, MMU access: Failed \n",
                                              calcTime(startTime), processNum);
              whereLogTo(configStruct, lineHolder, &fp);
              sprintf(lineHolder,
                    "Time: %ld, Process %d, Seg Fault - Process Ended \n",
                                              calcTime(startTime), processNum);
              whereLogTo(configStruct, lineHolder, &fp);
              sprintf(lineHolder,
                    "Time: %ld, Process %d, set in Exit State \n",
                                              calcTime(startTime), processNum);
              whereLogTo(configStruct, lineHolder, &fp);
              //Handle skipping rest of the Process
              endProcessFlag = 1;
            }
          }

        }
        //handle I/O:
        else if(charInString(temp->component, "I") == 0 ||
                                        charInString(temp->component, "O") == 0)
        {
          //Set passTime in milliSeconds
          passTime = ioTime * temp->value;

          sprintf(lineHolder, "Time: %ld, Process %d, %s  %c start \n",
             calcTime(startTime), processNum, temp->operation, temp->component);
          whereLogTo(configStruct, lineHolder, &fp);

          pthread_create(&workerThread, NULL, makeWait, &passTime);
          pthread_join(workerThread, NULL);

          sprintf(lineHolder, "Time: %ld, Process %d, %s  %c end \n",
             calcTime(startTime), processNum, temp->operation, temp->component);
          whereLogTo(configStruct, lineHolder, &fp);
        }
        //Run operation:
        else
        {
          passTime = processTime * temp->value;

          sprintf(lineHolder, "Time: %ld, Process %d, %s  operation start \n",
                              calcTime(startTime), processNum, temp->operation);
          whereLogTo(configStruct, lineHolder, &fp);

          pthread_create(&workerThread, NULL, makeWait, &passTime);
          pthread_join(workerThread, NULL);

          sprintf(lineHolder, "Time: %ld, Process %d, %s  operation end \n",
                              calcTime(startTime), processNum, temp->operation);
          whereLogTo(configStruct, lineHolder, &fp);
        }

      }
    }

    temp = temp->nextNode;
    //resets my char array:
    memset(lineHolder, '\0', sizeof(lineHolder));
  }
  fclose(fp);
}

//Function to help minimze code to calc time.  
unsigned long calcTime(struct timeval startTime)
{
  struct timeval curTime;
  unsigned long endingTime;

  gettimeofday(&curTime, NULL);
  endingTime = (curTime.tv_sec - startTime.tv_sec) * 1000000L +
                                      curTime.tv_usec - startTime.tv_usec;
  return endingTime;
}




#endif
