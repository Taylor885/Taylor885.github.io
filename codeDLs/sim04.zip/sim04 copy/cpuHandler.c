/**
*  @file cpuHandler.c
*
**/

#ifndef CPU_HANDLER_C
#define CPU_HANDLER_C

#include "processHandler.h"
#include "MetadataFileUpload.h"
#include "Utility.h"
#include "ConfigFileUpload.h"
#include "sjfHandler.h"
#include "cpuHandler.h"


//function to check Config file CPU Code
int checkCPUCode(char *scheduleCode)
{
  if (StringCompare(scheduleCode, "FCFS-N") == 0)
  {
    return 1;
  }
  else if (StringCompare(scheduleCode, "SJF-N") == 0)
  {
    return 2;
  }
  else if (StringCompare(scheduleCode, "FCFS-P") == 0)
  {
    return 3;
  }
  else if (StringCompare(scheduleCode, "SRTF-P") == 0)
  {
    return 4;
  }
  else if (StringCompare(scheduleCode, "RR-P") == 0)
  {
    return 5;
  }
  else
  {
    return 0;
  }
}


#endif
