/**
*  @file MetadataFileUpload.h
*
*  @details : Contains typedef for metadata nodes and
*             function declarations.
*  @version 1.2
*
*  @note : requires Utility.h
*
*/
#ifndef METADATA_UPLOAD_H
#define METADATA_UPLOAD_H

#include <stdio.h>
#include <stdlib.h>
#include "Utility.h"

typedef struct MetadataNode
{
   char component;
   char operation[255];
   int value; //either cycles or memory size

   struct MetadataNode *nextNode; //defaults to null

} MetadataNode;


//Function Declarations
ERROR_CODE ReadMetadataFile(char *, MetadataNode **);
MetadataNode *getMetadataNode(char *);
char getMetadataComponent(char *);
int getMetadataOperation(char *, char **);
int getMetadataValue(char *);
int checkComponent(char);
int checkOperation(char *);
MetadataNode *addNode(MetadataNode *, MetadataNode *);
MetadataNode *createNode(char, char *, int);
int listLength(MetadataNode *);
MetadataNode *clearList(MetadataNode *);

#endif
