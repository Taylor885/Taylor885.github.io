/**
*  @file sjfHandler.c
*
**/

#ifndef SJF_HANDLER_C
#define SJF_HANDLER_C

#include "processHandler.h"
#include "MetadataFileUpload.h"
#include "Utility.h"
#include "ConfigFileUpload.h"
#include "sjfHandler.h"


//function to check Config file CPU Code
int checkForSJF(char *scheduleCode)
{
  int isSJFFlag;
  if (StringCompare(scheduleCode, "SJF-N") == 0)
  {
    isSJFFlag = 1;
  }
  else if (StringCompare(scheduleCode, "FCFS-N") == 0)
  {
    isSJFFlag = 0;
  }
  else
  {
    isSJFFlag = 2;
  }
  return isSJFFlag;
}

//function to calculate SJF procecess times, store in
void calcProcessTimes(MetadataNode **currentNode , ConfigData *configStruct,
                                                            ProcTimesNode *lCur)
{
  //Store ioCycleTime and processerCycleTime for further use
  int ioTime = configStruct->ioCycleTime;
  int procCyleTime = configStruct->processerCycleTime;

  MetadataNode *temp = *currentNode;
  //ProcTimesNode *lCur = *leadNode;  -Couldn't get to work
  int processNum = -1;

  //outer loop iterating through All processes
  while(temp != NULL)
  {
    //last node in program, exit loop:
    if(charInString(temp->component, "S") == 0  &&
                                    StringCompare(temp->operation, "end") == 0)
    {
      break;
    }

    //Start of a new process
    else if(charInString(temp->component, "A") == 0  &&
                                  StringCompare(temp->operation, "start") == 0)
    {
      processNum++;
      int totalProcTime = 0;
      temp = temp->nextNode;

      //Inner loop, iterating through all nodes in a Single process
      while(charInString(temp->component, "A") != 0  &&
                                     StringCompare(temp->operation, "end") != 0)
      {
        //Nodes will either be I/O, Run, or Memory
        if(charInString(temp->component, "I") == 0 ||
                                        charInString(temp->component, "O") == 0)
        {
          totalProcTime = totalProcTime + (procCyleTime * temp->value);
        }
        //Run
        else if ((charInString(temp->component, "P") == 0))
        {
          totalProcTime = totalProcTime + (ioTime * temp->value);
        }
        //Else memory, assuming a fixed amount of time: 5
        else
        {
          totalProcTime = totalProcTime + 5;
        }

        temp = temp->nextNode;
      }

      //Found end process node,store calculated total process time
      lCur->procNum = processNum;
      lCur->totalProcTime = totalProcTime * 1000;

      //point to next metaDataNode and skip to top of loop
      temp = temp->nextNode;
      continue;
    }
    temp = temp->nextNode;
  }
}

/* Function to check memory allocated is within Config file parameters,
    And stores them in MMU
*/
int memoryChecker(MetadataNode **currentNode,
                          ConfigData *configStruct, MMU *memAllocated)
{
  MetadataNode *temp = *currentNode;

  int memAvailable = configStruct->memoryAvailable;
  int memHolder = temp->value;

  int memRequested = memHolder % 1000;
  memAllocated->memAlloc = memRequested;

  int memSegment = memHolder / 1000000;
  memAllocated->segment = memSegment;

  int memBase = memHolder/ 1000;
  memBase = memBase % 1000;
  memAllocated->memBase = memBase;

  //check if memory is > then specified in config file
  if(memRequested > memAvailable)
  {
    return 0;
  }
  return 1;
}

//Function to check if Access is within the MMU and allocation
int memoryAccess(MetadataNode **currentNode, ConfigData *configStruct,
                                                            MMU *memAllocated)
{
  MetadataNode *temp = *currentNode;

  //Allocated values
  int memTotal = memAllocated->memBase + memAllocated->memAlloc;

  //Calculations of Access node:
  int memHolder = temp->value;
  int memSegment = memHolder / 1000000;
  int memRequested = memHolder % 1000;
  int memBase = memHolder/ 1000;
  memBase = memBase % 1000;

  //Handle all possible segfaults:
  if (memBase < memAllocated->memBase)
  {
    return 0;
  }
  else if (memSegment != memAllocated->segment)
  {
    return 0;
  }
  else if (memTotal < (memBase + memRequested))
  {
    return 0;
  }

  return 1;
}

#endif
