/*
*  @file Sim04.c
*
*  @details-1 : Main driver program which reads config and metadata files
*               and dumps data retrieved to the screen.

*  @details-2: Main driver now processes Meta Data Nodes, creating threads,
*              outputting to Files/Monitor, and a waiting timer
*
*  @details-3: Main driver now checks for SJF-N or FCFS-N.  Also, correctly
*              checks and handles for memory allocation and access.
*              Calculates process time, but ProcTimesNode Linked List not
*              correctly implemented.  Therefore can not Sort processes.
*
*              New code: sjfHandler.c
*                        and processMetadata() -memory section/nodes
*
*  @details-4: Project incorporates 3 new CPU Scheduling strategies: FCFS-P,
*              SRTF-P, and RR-P.  These strategies are checked in cpuHandler,
*              and a switch() statement checks them in processMetadata(), where
*              a sorting algorithm could be implemented/called in the future.
*
*  @to Grader: processMetadata() found in processHandler.c does repeat code,
*              and is not the cleanest.  However, most of this was for past
*              Sims, and it was already accounted for in those grades.
*              I added a calcTime() function to help with Repeating Code.
*
*  @note : requires ConfigFileUpload.h MetadataFileUpload.h Utility.h
*          processHandler.h, sjfHandler.h, and cpuHandler.c
*/
#ifndef SIM_04
#define SIM_04

#include "ConfigFileUpload.h"
#include "MetadataFileUpload.h"
#include "Utility.h"
#include "processHandler.h"
#include "sjfHandler.h"
#include "cpuHandler.h"

int main(int argc, char *argv[])
{
   ConfigData *configData = (ConfigData *)malloc(sizeof(ConfigData));
   MetadataNode *headNode = NULL;

   ERROR_CODE returnStatus;
   if(argc != 2)
   {
     printf("Please include file name like so: ./sim01_driver <config_file>\n");
     return -1;
   }

   returnStatus = ReadConfigFile(argv[1], configData);

   if(returnStatus == SUCCESS)
   {
     //Then ReadMetadataFile()
     returnStatus = ReadMetadataFile(configData->filePath, &headNode);
     if(returnStatus == SUCCESS)
     {
       //Then Config and Metadata uploaded.  Make Sim03 calls
       MMU *memAllocated = (MMU *)malloc(sizeof(MMU));
       int cpuChecker = checkCPUCode(configData->scheduleCode);

       if(cpuChecker)
       {
         printf("Operating System Simulator \n");
         printf("========================== \n");
         processMetadata(&headNode, configData, cpuChecker, memAllocated);
       }
       else
       {
         printf("Error, config file does not contain a valid CPU code. \n");
         printf("Please use a config file with a designated CPU code. \n");
       }
     }
     else if(returnStatus == FILE_OPEN_ERROR)
     {
       printf("Could not open Metadata file!\n");
     }
     else
     {
       printf("There's something wrong with your metadata file!\n");
     }

     free(configData);
   }
   else if(returnStatus == FILE_OPEN_ERROR)
   {
     printf("Could not open config file!\n");
   }
   else
   {
     printf("There's something wrong with your config file!\n");
   }

  headNode = clearList(headNode);
  return 0;
}

#endif
