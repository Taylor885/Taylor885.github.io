/**
*  @file MetadataFileUpload.c
*
*  @details : Contains functions that read the metadata file
*             and deals with storing metadata nodes.
*
*  @version 1.2
*
*  @note : requires MetadataFileUpload.h and Utility.h
*
*  @note 2 : Metadata node functions inspired by Prof. Levrington's
*            linked list code.
*/
#ifndef METADATA_UPLOAD_C
#define METADATA_UPLOAD_C

#include "MetadataFileUpload.h"
#include "Utility.h"



ERROR_CODE ReadMetadataFile(char *fileName, MetadataNode **headNode)
{
   FILE *filePtr;
   int running = 1;
   int lineIndex;
   char current;
   char *lineBuffer = malloc(sizeof(char)*255);
   int foundStartLine = 0;
   int foundEndLine = 0;

   filePtr = fopen(fileName, READ_ONLY_FLAG);
   if(filePtr == NULL)
   {
     free(lineBuffer);
     return FILE_OPEN_ERROR;
   }

   while(!feof(filePtr) && running == 1)
   {
      //fill line buffer
      current = fgetc(filePtr);
      lineIndex = 0;

      while(current != ';' && current != ':' && current != '.' &&
            current != 0 && !feof(filePtr))
      {
         //if line is too long return error
         if(lineIndex > 255)
         {
           return FILE_READ_ERROR;
         }
         lineBuffer[lineIndex] = current;
         current = fgetc(filePtr);
         lineIndex++;
      }
      lineBuffer[lineIndex] = 0;
      Strip(lineBuffer);

      if(current == ':')
      {
         if(StringCompare("StartProgramMeta-DataCode", lineBuffer) != 0)
         {
           free(lineBuffer);
           fclose(filePtr);
           return FILE_READ_ERROR;
         }
         foundStartLine++;
      }
      else if(current == ';' || current == '.')
      {
         if(StringCompare(lineBuffer, "EndProgramMeta-DataCode") == 0)
         {
            foundEndLine++;
            running = 0;
         }
         else //Not foundStartLine or foundEndLine....?
         {
           //Create Metadata Node
           MetadataNode *newNode = getMetadataNode(lineBuffer);

           if(newNode == NULL)
           {
             free(newNode);
             free(lineBuffer);
             fclose(filePtr);
             return FILE_READ_ERROR;
           }
           *headNode = addNode(*headNode, newNode);
         }
      }
      else
      {
         free(lineBuffer);
         fclose(filePtr);
         return FILE_READ_ERROR;
      }
   }
  free(lineBuffer);
  fclose(filePtr);
  if(foundStartLine == 1 && foundEndLine ==1)
  {
    return SUCCESS;
  }
  return FILE_READ_ERROR;
}

//returns null if string not formatted correctly
MetadataNode *getMetadataNode(char *inString)
{
  char component;
  char *operation = malloc(sizeof(char)*255);
  MetadataNode *returnNode;
  int value;

  component = getMetadataComponent(inString);
  if(component == 0)
  {
    free(operation);
    return NULL;
  }

  if(getMetadataOperation(inString, &operation) < 0)
  {
    free(operation);
    return NULL;
  }
  value = getMetadataValue(inString);
  if(value < 0)
  {
    free(operation);
    return NULL;
  }
  returnNode = createNode(component, operation, value);
  free(operation);
  return returnNode;

}

char getMetadataComponent(char *inString)
{
  char buffer[2];
  int stringIndex = 0;
  int bufferIndex = 0;

  Strip(inString);

  while(inString[stringIndex] != '(' && bufferIndex < 2)
  {
    buffer[bufferIndex] = inString[stringIndex];
    stringIndex++;
    bufferIndex++;
  }
  buffer[bufferIndex] = 0;
  if(StringLength(buffer) > 1)
  {
    return 0;
  }
  if(checkComponent(buffer[0]) != 0)
  {
    return 0;
  }

  return buffer[0];

}

int getMetadataOperation(char *inString, char **outString)
{
  char buffer[255];
  int stringIndex = 0;
  int bufferIndex = 0;

  Strip(inString);

  while(inString[stringIndex] != '(' && inString[stringIndex] != 0)
  {
    stringIndex++;
  }
  stringIndex++;

  while(inString[stringIndex] != ')' && inString[stringIndex] != 0)
  {
    buffer[bufferIndex] = inString[stringIndex];
    stringIndex++;
    bufferIndex++;
  }
  buffer[bufferIndex] = 0;

  if(checkOperation(buffer) != 0)
  {
    return -1;
  }

  StringCopy(*outString, buffer);

  return 0;
}

int getMetadataValue(char * inString)
{
  char buffer[255];
  int stringIndex = 0;
  int bufferIndex = 0;


  Strip(inString);

  while(inString[stringIndex] != ')' && inString[stringIndex] != 0)
  {
    stringIndex++;
  }
  stringIndex++;
  while(inString[stringIndex] != 0)
  {
    buffer[bufferIndex] = inString[stringIndex];
    stringIndex++;
    bufferIndex++;
  }
  buffer[bufferIndex] = 0;

  return stringToInt(buffer);


}

int checkComponent(char inComp)
{
  if(charInString(inComp, "SAPMIO") == 0)
  {
    return 0;
  }

  return -1;
}

int checkOperation(char * inOperation)
{
  if(StringCompare(inOperation, "access") == 0 ||
     StringCompare(inOperation, "allocate") == 0 ||
     StringCompare(inOperation, "end") == 0 ||
     StringCompare(inOperation, "harddrive") == 0 ||
     StringCompare(inOperation, "keyboard") == 0 ||
     StringCompare(inOperation, "printer") == 0 ||
     StringCompare(inOperation, "monitor") == 0 ||
     StringCompare(inOperation, "run") == 0 ||
     StringCompare(inOperation, "start") == 0)
  {
    return 0;
  }

  return -1;

}


MetadataNode *addNode(MetadataNode *headNode, MetadataNode *newNode)
{
   if(headNode != NULL)
   {
     MetadataNode *temp = headNode;
     while(temp->nextNode != NULL)
     {
       temp = temp->nextNode;
     }

     temp->nextNode = newNode;
   }
   else
   {
     headNode = newNode;
   }

   return headNode;
}

MetadataNode *createNode(char inComponent, char *inOperation, int inValue)
{
  MetadataNode *newNode = (MetadataNode *) malloc(sizeof(MetadataNode));

  newNode->component = inComponent;
  StringCopy(newNode->operation, inOperation);
  newNode->value = inValue;
  newNode->nextNode = NULL;
  return newNode;
}

//Used mainly for testing purposes
int listLength(MetadataNode *headNode)
{
  int count = 0;

  if(headNode != NULL)
  {
    count++;
    MetadataNode *temp = headNode;
    while(temp->nextNode != NULL)
    {
      temp = temp->nextNode;
      count++;

    }
    return count;
  }

  return count;
}

//Maybe need to not clear this....  Then read it in other file
MetadataNode *clearList(MetadataNode *headNode)
{
  if(headNode == NULL)
  {
    return headNode;
  }

  if(headNode->nextNode != NULL)
  {
    clearList(headNode->nextNode);
  }

  free(headNode);
  headNode = NULL;
  return headNode;
}


#endif
