/**
*  @file Utility.c
*
*  @details : Contains functions which help with string processing.
*
*  @version 1.2
*
*  @note : requires Utility.h
*/
#ifndef UTILITY_C
#define UTILITY_C

#include "Utility.h"

int charInString(char inChar, char *inString)
{
  int index = 0;
  while(inString[index] != 0)
  {
    if(inString[index] == inChar)
    {
      //found character
      return 0;
    }
    index++;
  }
  //character not found
  return -1;
}

int charToInt(char inChar)
{
  return (int) inChar - '0';
}

int isDigit(char *inString)
{
  int index = 0;
  while(inString[index] != 0)
  {
    if(inString[index] < 48 || inString[index] > 57)
    {
      return -1;
    }
    index++;
  }

  return 0;
}

int stringToInt(char *inString)
{
  if(isDigit(inString) != 0)
  {
    return -1;
  }
  int result = 0;
  int index = 0;
  while(inString[index] != 0)
  {
    result = result * 10 + charToInt(inString[index]);
    index++;
  }

  return result;
}
//Removes whitespace from string
void Strip(char *string)
{
   char *buffer = malloc(sizeof(char) * 255);
   int current = 0;
   int bufferIndex = 0;

   while(string[current] != 0)
   {
     if(string[current] > 32)
     {
       buffer[bufferIndex] = string[current];
       bufferIndex++;
     }
     current++;
   }

   buffer[bufferIndex] = 0;
   StringCopy(string, buffer);
   free(buffer);
}


//returns 0 if true, -1 if false
int StringCompare(char *string1, char *string2)
{
   if(StringLength(string1) != StringLength(string2))
   {
     return -1;
   }

   for(int index = 0; index < StringLength(string1); index++)
   {
     if(string1[index] != string2[index])
     {
       return -1;
     }
   }

   return 0;

}

int StringLength(char *string)
{
   int count = 0;
   while(string[count] != 0)
   {
     count++;
   }

   return count;
}

void StringCopy(char *destination, char *buffer)
{
  if(buffer == NULL || destination == NULL)
  {
    return;
  }

  int index = 0;
  while(buffer[index] != 0)
  {
    destination[index] = buffer[index];
    index++;
  }

  destination[index] = 0;

}

#endif
