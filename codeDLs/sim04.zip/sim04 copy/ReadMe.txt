*** Project at a Glance: ***
"I will explain what I was and was not able to complete, therefore it will make it easier for you, the grader, to follow along with the outputs and determine a grade.
I was able to check and implement the new CPU codes, but had problems with the sorting algorithms.  I attempted to make and implement a "ProcTimesNode" LinkedList to help with the sorting of the processes, however could not get it to correctly compile, so ended up not implementing it.  I did implement Memory Management, allocation and access function correctly. 
I did create threads, and I did set up my code in a way that made it organized to call sorting algorithms if I got them implemented (see switch() in processMetadata() ). However, was not able to correctly handle interrupts for the scheduling queue. processHandler.c, sjfHandler.c, and cpuHandler.c will probably be of the most interest for this final sim."


*** Testing: ***
Program does correctly compile and run, choosing the cpu scheduling process. However, since I was unable to implement the sorting algorithms, the process outputs will all be according to FCFS-N. And, I used the same metadata file for simplicity, so outputs will be similar. All files can be found correctly labeled in "Testing_References" folder.
